#ifndef OBJ_H
#define OBJ_H
using namespace std;

class Objects {
public:
	Objects(char name);
	void setd(int d);
	void setb(int b);
	int getd() const;
	int getb() const;
	char getc() const;


private:
	int damage;
	int bonus;
	char name;//action
};

class weapon : public Objects
{
public:
	weapon(char s);
};

class scroll :public Objects
{
public:
	scroll(char s);
};
#endif