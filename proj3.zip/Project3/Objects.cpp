#include "Objects.h"

Objects::Objects(char s)
{
	name = s;
}
void Objects::setd(int d)
{
	damage = d;
}
void Objects::setb(int b)
{
	bonus = b;
}
int Objects::getd() const
{
	return damage;
}
int Objects::getb() const
{
	return bonus;
}
char Objects::getc() const
{
	return name;
}


weapon::weapon(char s)
:Objects(s)
{
	switch (s)
	{
	case 's':
	{
		setd(2);
		setb(0);

	}
	case 'l':
	{
		setd(4);
		setb(2);
	}
	case 'a':
	{
		setd(5);
		setb(5);
	}
	case 'f':
	{

	}
	}
}
scroll::scroll(char s)
	: Objects(s)
{
	setd(2);
	setb(3);
}