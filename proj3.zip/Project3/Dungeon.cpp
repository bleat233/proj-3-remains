#include "Dungeon.h"
#include "Objects.h"
#include <iostream>
#include <string>
using namespace std;

Dungeon::Dungeon(int b, int s,int l)
{
	lvl = l;
	m_box = b;
	m_size = s;
	m_player = new player(5, 5);
	
}
Dungeon::~Dungeon()
{
	delete m_player;
}
void Dungeon::display(string msg)
{

	for (int r = 0; r < 18; r++)
	{
		for (int c = 0; c < 70; c++)
		{
			if (r == 0 or c == 0 or c == 69 or r == 17)
				d[r][c] = '#';
			else
				d[r][c] = ' ';
		}
	}

	d[m_player->getr()][m_player->getc()] = '@';
	for (int r = 0; r < 18; r++)
	{
		for (int c = 0; c < 70; c++)
		{
			cout << d[r][c];
		}
		cout << endl;
	}
	cout << msg;
}

void Dungeon::set(int x, int y, char c)
{
	d[x][y] = c;
}

char Dungeon::get(int x, int y) const
{
	return d[x][y];
}

player* Dungeon::getplayer() const
{
	return m_player;
}