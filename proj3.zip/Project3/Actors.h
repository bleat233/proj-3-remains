#ifndef ACT_H
#define ACT_H
#include "Objects.h"
#include "utilities.h"
#include <string>
using namespace std;


class Actors {
public:
	Actors(int r, int c, int hp, weapon wp, int ap, int sp, int dp);
	virtual string move(char dir) = 0;
	int getc() const;
	int getr() const;
	void setr(int row);
	void setc(int col);
	void setwp(weapon w);
	string fight(Actors &enmy);
	string pickup(Objects &obj);

private:
	//The actor's current position in the level.
	int r;
	int c;
	//Hit points
	int hp;
	weapon wp;
	//Armor points
	int ap;
	//Strength points
	int sp;
	//dexterity ponits
	int dp;
	//sleep time
};
class player : public Actors
{
public:
	player(int r, int c);
	virtual string move(char dir) ;
	bool Dead();
	bool Win();

};
class goblin : public Actors
{
public:
	goblin(int r, int c);
};
class dragon : public Actors
{
public:
	dragon(int r, int c);

};

class bman : public Actors
{
public:
	bman(int r, int c);


};
class snake : public Actors
{
public:
	snake(int r, int c);


};

#endif