// Game.h

#ifndef GAME_INCLUDED
#define GAME_INCLUDED
#include "Dungeon.h"
#include "utilities.h"
#include "Objects.h"
#include "Actors.h"
#include <vector>

// You may add data members and other member functions to this class.

class Game
{
public:

    string action();
    Game(int goblinSmellDistance);
    void play();
    void descend();
private:
    Dungeon* d;
};

#endif // GAME_INCLUDED
