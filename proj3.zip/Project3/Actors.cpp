#include "Actors.h"
using namespace std;


Actors::Actors(int r, int c, int hp, weapon wp, int ap, int sp, int dp)
	:r(5), c(5),hp(99),wp(weapon('s')),ap(99),sp(0),dp(99)
{}

void Actors::setwp(weapon w)
{
    wp = w;
}
void Actors::setr(int row) 
{
    r = row;
}

void Actors::setc(int col)
{
    c = col;
}

string Actors::fight(Actors& enmy)
{
    //fighting
    //modify enmy and self status
    return "fighting";

}

string Actors::pickup(Objects &obj)
{
    //change inventory
    return "pick up sth";
    //pick up weapon or scroll
}
player::player(int r, int c)
	: Actors(r, c, 20, weapon('s'),2, 2, 2)
{
	//short sword
}

bool player::Dead()
{
    return false;
}

bool player::Win()
{
    return false;
}


int Actors::getc() const
{
    return c;
}

int Actors::getr() const
{
    return r;
}

string player::move(char dir)
{
    string msg;
    int row = getr();
    int col = getc();
    switch (dir)
    {
    case ARROW_UP: setr(row - 1); break;
    case ARROW_RIGHT: setc(col + 1); break;
    case ARROW_DOWN: setr(row + 1); break;
    case ARROW_LEFT: setc(col - 1); break;
    }
    string status = "Dungeon Level: \n";
    return status + msg;
}
goblin::goblin(int r, int c)
    : Actors(r, c, randInt(15, 20), weapon('s'), 1, 1, 3)
{
    //short swords
}
dragon::dragon(int r, int c)
    : Actors(r, c, randInt(20,25),weapon('l'), 4, 4, 4)
{

}
snake::snake(int r, int c)
    : Actors(r, c, randInt(3, 6), weapon('f'), 3, 2, 3)
{
    //magic fangs to sleep
}
bman::bman(int r, int c)
    : Actors(r, c, randInt(5,10), weapon('s'), 2, randInt(2,3), randInt(2,3))
{
    //short swords
}

