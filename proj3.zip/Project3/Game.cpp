// Game.cpp

#include "Game.h"
#include <algorithm>
#include <string>
#include <iostream>
using namespace std;

// Implement these and other Game member functions you may have added.

Game::Game(int goblinSmellDistance)
{
    //generate a new dungeon
    d = new Dungeon(0, 0, 1);
}

string Game::action()
{
    for (;;)
    {
        player* p = d->getplayer();
        char dir = getCharacter();
        string msg;
        if (p == nullptr or dir == 'q')
            return "quit";
        else
        {
            int r = p->getr();
            int c = p->getc();
            switch (dir)
            {
            case ARROW_UP: if (r <= 0)        return "quit"; else r--; break;
            case ARROW_RIGHT:  if (c >= 70) return "quit"; else c++; break;
            case ARROW_DOWN: if (r >= 18) return "quit"; else r++; break;
            case ARROW_LEFT:  if (c <= 0)        return "quit"; else c--; break;
            }
            char nxt = d->get(r, c);

            switch (nxt)
            {
                //prompt again?
                case '#':
                    return action();
                //just moving
                case ' ':
                {
                    msg+= p->move(dir);
                    break;
                }
                case ')':
                {
                    msg += p->move(dir);
                    if (getCharacter() == 'g')
                        msg += "weapon";
                    break;
                    //using find if to get the weapon at that coord
                   //return p->pickup(find_if()) and pick up will return a string
                }
                case '&':
                {
                    msg += p->move(dir);
                    p->Win();
                    break;
                }
                case '>':
                {
                    msg += p->move(dir);
                    if (getCharacter() == '>')
                        descend();
                    break;
                }
                //do you wanna fight the monster?
                case 'S':
                case 'D':
                case 'G':
                case 'B':
                {//fight, and fight will return string,using find_if to get the monster from the vec list
                    msg += "fighting placeholder";
                    //return p->fight();
                    break;
                }
            }
        }
        return msg;
    }
}

void Game::descend()
{
    cout << "generate new level" << endl;
    //generate new level map
}
void Game::play()
{
    player* p = d->getplayer();
    string msg;
    do
    {
       clearScreen();
       d->display(msg);
       cout << "Press q to exit game." << endl;
       msg = action();
       /*d->monsterMove();*/
    } while (msg != "quit" && !p->Dead() && !p->Win());
    if (p->Dead())
        cout << "You lose." << endl;
    else if (p->Win())
        cout << "You win." << endl;
    else
        cout << "You quit." << endl;
}

// You will presumably add to this project other .h/.cpp files for the
// various classes of objects you need to play the game:  player, monsters,
// weapons, etc.  You might have a separate .h/.cpp pair for each class
// (e.g., Player.h, Boegeyman.h, etc.), or you might put the class
// declarations for all actors in Actor.h, all game objects in GameObject.h,
// etc.
