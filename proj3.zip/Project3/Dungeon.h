#ifndef DUN_H
#define DUN_H
#include "utilities.h"
#include "Actors.h"
#include "Objects.h"
#include <vector>
#include <string>
class Dungeon
{
public:
	Dungeon(int b, int s, int l);
	void display(string msg);
	void set(int x, int y, char c);
	char get(int x, int y) const;
	~Dungeon();
	player* getplayer() const;
private:
	char d[18][70];
	int m_box;
	int m_size;
	int lvl;
	vector<Objects> objv;
	vector<Actors> mon;
	player* m_player;
};


#endif
